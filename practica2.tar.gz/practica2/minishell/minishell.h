#ifndef MINISHELL_H
#define MINISHELL_H
#include <sys/types.h>

#include "internas.h"
#include "entrada_minishell.h"
#include "ejecutar.h"

int main(int argc, char *argv[]);

#endif
